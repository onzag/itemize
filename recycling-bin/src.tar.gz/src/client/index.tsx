import React from "react";
import { initializeItemizeApp } from "../../itemize/client";
import App from "./app";

initializeItemizeApp(
  <App/>,
);
